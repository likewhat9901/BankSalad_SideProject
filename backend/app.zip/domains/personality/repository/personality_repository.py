import pandas as pd
import calendar
from logger import setup_logger

from app.common.utils import parse_date_params
from app.domains.transaction.repository.transaction_repository import load_transactions_from_parquet
from app.domains.personality.models import (
    personality_data,
)

logger = setup_logger(__name__)


def load_expense_transactions(
    year: int | None = None,
    month: int | None = None
) -> pd.DataFrame:
    """지출 거래 데이터 로드 및 필터링
    
    Args:
        year: 연도 (선택)
        month: 월 (선택)
    
    Returns:
        필터링된 지출 거래 DataFrame
    """
    # 날짜 파라미터 파싱
    start_date, end_date = parse_date_params(year, month, None, None)
    
    # 데이터 로드
    df = load_transactions_from_parquet()
    
    # 날짜 필터링
    if start_date:
        df = df[df["거래일시"] >= pd.to_datetime(start_date)]
    if end_date:
        df = df[df["거래일시"] <= pd.to_datetime(end_date)]
    
    # 지출 데이터만 필터링
    df = df[df["타입"] == "지출"].copy()
    df["금액"] = df["금액"].abs()
    
    return df


def get_personality_info(personality_type: str) -> dict:
    """유형별 정보 조회
    
    Args:
        personality_type: 유형 코드 (예: "PRHS")
    
    Returns:
        유형 정보 딕셔너리
    """
    return personality_data.get(personality_type, personality_data["Unknown"])


def get_default_personality() -> dict:
    """기본 유형 정보 반환"""
    return personality_data["Unknown"]