from config import get_parquet_path
import pandas as pd

def load_transactions_from_parquet() -> pd.DataFrame:
    """거래내역 parquet 파일을 로드"""
    parquet_path = get_parquet_path()
    if not parquet_path.exists():
        raise FileNotFoundError(f"거래내역 parquet 파일 없음: {parquet_path}")
    return pd.read_parquet(parquet_path)