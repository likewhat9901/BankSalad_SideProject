from fastapi import APIRouter, UploadFile, File, HTTPException
from logger import setup_logger

from app.domains.upload.services.excel_converter_service import excel_to_parquet
from app.domains.upload.utils.file_validation import validate_excel_file
from config import RES_DATA_DIR

logger = setup_logger(__name__)

upload_router = APIRouter(prefix="/upload", tags=["업로드"])


@upload_router.post("/excel")
async def upload_excel(file: UploadFile = File(...)):
    """엑셀 파일 업로드 및 변환"""
    content = await file.read()
    validate_excel_file(file, content)
    
    try:
        excel_file_path = RES_DATA_DIR / file.filename
        with open(excel_file_path, "wb") as f:
            f.write(content)
        
        result = excel_to_parquet(excel_file_path)
        logger.info(f"엑셀 파일 변환 완료: {result['message']}")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"업로드 중 오류 발생: {type(e).__name__}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))