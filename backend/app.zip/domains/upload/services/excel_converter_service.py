from pathlib import Path
import pandas as pd
from logger import setup_logger
from config import get_parquet_path

logger = setup_logger(__name__)


def excel_to_parquet(
    excel_file_path: Path, 
    sheet_name: int = 1,
) -> dict:
    """엑셀 파일을 Parquet로 변환
    
    Args:
        excel_file_path: 변환할 엑셀 파일 경로
        sheet_name: 읽을 시트 번호 (기본값: 1)
    
    Returns:
        변환 결과 딕셔너리
    """
    logger.info(f"엑셀 파일 '{excel_file_path.name}' 변환 시작")
    
    # 엑셀 파일 읽기
    df = _read_excel_file(excel_file_path, sheet_name)
    
    # 데이터 가공
    df = _process_transaction_data(df)
    
    # Parquet 파일로 저장
    output_path = get_parquet_path()
    _save_to_parquet(df, output_path)
    
    return {
        "status": "success",
        "message": f"'{excel_file_path.name}' 변환 완료",
        "output_file": str(output_path)
    }


def _read_excel_file(excel_file_path: Path, sheet_name: int) -> pd.DataFrame:
    """엑셀 파일 읽기"""
    try:
        df = pd.read_excel(excel_file_path, sheet_name=sheet_name)
        logger.info(f"엑셀 파일 읽기 완료: {len(df)}행 x {len(df.columns)}열")
        return df
    except Exception as e:
        logger.error(f"엑셀 파일 읽기 오류: {e}")
        raise


def _process_transaction_data(df: pd.DataFrame) -> pd.DataFrame:
    """거래 데이터 가공"""
    # 거래일시 생성
    df['거래일시'] = pd.to_datetime(df['날짜'], unit='ms') + pd.to_timedelta(df['시간'].astype(str))
    
    # 컬럼 재정렬
    other_cols = [col for col in df.columns if col not in ['거래일시', '날짜', '시간']]
    df = df[['거래일시'] + other_cols]
    
    # ID 컬럼 추가
    df = df.sort_values("거래일시", ascending=False).reset_index(drop=True)
    df['id'] = (len(df) - 1) - df.index
    
    # ID 컬럼을 첫 번째 위치로 이동
    cols = ['id'] + [col for col in df.columns if col != 'id']
    df = df[cols]
    
    return df


def _save_to_parquet(df: pd.DataFrame, output_path: Path) -> None:
    """DataFrame을 Parquet 파일로 저장"""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        df.to_parquet(output_path, index=False)
        file_size_mb = output_path.stat().st_size / (1024 * 1024)
        logger.info(f"Parquet 파일 저장 완료: '{output_path}' ({file_size_mb:.2f} MB)")
    except Exception as e:
        logger.error(f"Parquet 저장 오류: {e}")
        raise