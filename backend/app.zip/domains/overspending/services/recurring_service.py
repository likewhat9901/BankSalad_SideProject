import pandas as pd
from logger import setup_logger

from app.common.utils import parse_date_params
from app.domains.transaction.repository import load_transactions_from_parquet

logger = setup_logger(__name__)


# --------------------------------
# public functions
# --------------------------------
def analyze_recurring(
    year: int | None = None,
    month: int | None = None,
    min_count: int = 3
) -> list[dict]:
    """반복 소비 패턴 분석
    
    Args:
        year: 연도 (선택)
        month: 월 (선택)
        min_count: 최소 반복 횟수 (기본값: 3)
    
    Returns:
        반복 소비 패턴 리스트
    """
    try:
        # 데이터 준비
        df = _prepare_expense_data(year, month)
        if df.empty:
            return []
        
        # 시간/요일 데이터 추가
        df = _enrich_with_time_data(df)
        
        # 반복 소비 패턴 탐지
        patterns = _detect_recurring_patterns(df, min_count)
        
        logger.info(f"반복 소비 패턴 {len(patterns)}건 감지")
        return patterns
        
    except Exception as e:
        logger.error(f"반복 소비 분석 실패: {e}")
        raise


# --------------------------------
# private functions
# --------------------------------
def _prepare_expense_data(
    year: int | None = None,
    month: int | None = None
) -> pd.DataFrame:
    """거래 데이터 로드 및 지출 데이터 필터링
    
    Args:
        year: 연도 (선택)
        month: 월 (선택)
    
    Returns:
        필터링된 지출 데이터 DataFrame
    """
    # 날짜 파라미터 파싱
    start_date, end_date = parse_date_params(year, month, None, None)
    
    # 데이터 로드
    df = load_transactions_from_parquet()
    
    # 날짜 필터링
    df = _filter_by_date_range(df, start_date, end_date)
    if df.empty:
        return df
    
    # 지출 데이터만 필터링
    df = _filter_expense_only(df)
    
    return df


def _filter_by_date_range(
    df: pd.DataFrame,
    start_date: str | None,
    end_date: str | None
) -> pd.DataFrame:
    """날짜 범위로 데이터 필터링
    
    Args:
        df: 원본 DataFrame
        start_date: 시작일 (YYYY-MM-DD 형식)
        end_date: 종료일 (YYYY-MM-DD 형식)
    
    Returns:
        필터링된 DataFrame
    """
    if start_date:
        df = df[df["거래일시"] >= pd.to_datetime(start_date)]
    if end_date:
        df = df[df["거래일시"] <= pd.to_datetime(end_date)]
    
    return df


def _filter_expense_only(df: pd.DataFrame) -> pd.DataFrame:
    """지출 데이터만 필터링 및 금액 절댓값 변환
    
    Args:
        df: 원본 DataFrame
    
    Returns:
        지출 데이터만 포함한 DataFrame
    """
    df = df[df["타입"] == "지출"].copy()
    df["금액"] = df["금액"].abs()
    
    # 날짜 데이터 타입 확인
    if not pd.api.types.is_datetime64_any_dtype(df["거래일시"]):
        raise ValueError("거래일시 데이터 타입 오류")
    
    return df


def _enrich_with_time_data(df: pd.DataFrame) -> pd.DataFrame:
    """시간 및 요일 데이터 추가
    
    Args:
        df: 원본 DataFrame
    
    Returns:
        시간/요일 데이터가 추가된 DataFrame
    """
    df["hour"] = df["거래일시"].dt.hour
    df["day_of_week"] = df["거래일시"].dt.day_name()  # Monday, Tuesday, ...
    df["date"] = df["거래일시"].dt.date
    
    return df


def _detect_recurring_patterns(df: pd.DataFrame, min_count: int) -> list[dict]:
    """반복 소비 패턴 탐지
    
    기준:
    1. 동일 상호 (내용)
    2. 동일 시간대 (시간대 그룹화: 0-6, 6-12, 12-18, 18-24)
    3. 동일 요일 (선택적)
    
    Args:
        df: 분석할 DataFrame
        min_count: 최소 반복 횟수
    
    Returns:
        반복 소비 패턴 리스트
    """
    patterns = []
    
    # 시간대 그룹화
    df["time_range"] = df["hour"].apply(_get_time_range)
    
    # 그룹화 기준: 상호명 + 시간대 + 카테고리 + 결제수단
    grouping_cols = ["내용", "time_range", "대분류", "결제수단"]
    grouped = df.groupby(grouping_cols)
    
    for (merchant, time_range, category, payment_method), group in grouped:
        count = len(group)
        
        if count < min_count:
            continue
        
        pattern = _create_pattern_dict(
            group, merchant, time_range, category, payment_method, count
        )
        patterns.append(pattern)
    
    # 총액 기준 내림차순 정렬
    patterns.sort(key=lambda x: x["total_amount"], reverse=True)
    
    return patterns


def _get_time_range(hour: int) -> str:
    """시간을 시간대 범위 문자열로 변환
    
    Args:
        hour: 시간 (0-23)
    
    Returns:
        시간대 범위 문자열 (예: "00:00-06:00")
    """
    if 0 <= hour < 6:
        return "00:00-06:00"
    elif 6 <= hour < 12:
        return "06:00-12:00"
    elif 12 <= hour < 18:
        return "12:00-18:00"
    else:
        return "18:00-24:00"


def _create_pattern_dict(
    group: pd.DataFrame,
    merchant: str,
    time_range: str,
    category: str,
    payment_method: str,
    count: int
) -> dict:
    """반복 패턴 딕셔너리 생성
    
    Args:
        group: 그룹화된 DataFrame
        merchant: 상호명
        time_range: 시간대 범위
        category: 카테고리
        payment_method: 결제수단
        count: 반복 횟수
    
    Returns:
        패턴 딕셔너리
    """
    amounts = group["금액"].tolist()
    dates = group["거래일시"].dt.date.tolist()
    
    # 날짜 정렬
    sorted_dates = sorted(dates)
    first_date = sorted_dates[0]
    last_date = sorted_dates[-1]
    
    # 요일 확인 (모두 같은 요일인지)
    day_of_week = None
    days = group["day_of_week"].unique()
    if len(days) == 1:
        day_of_week = days[0]
    
    # 패턴 키 생성
    pattern_key = f"{merchant}_{time_range}_{category}_{payment_method}"
    
    # 평균 금액 계산
    average_amount = int(sum(amounts) / len(amounts))
    total_amount = int(sum(amounts))
    
    # 주기 계산 (일 단위)
    period_days = 0
    if count > 1:
        days_diff = (last_date - first_date).days
        period_days = days_diff // (count - 1) if count > 1 else 0
    
    return {
        "key": pattern_key,
        "merchant": merchant,
        "time_range": time_range,
        "day_of_week": day_of_week,
        "category": category,
        "payment_method": payment_method,
        "count": count,
        "total_amount": total_amount,
        "average_amount": average_amount,
        "first_date": first_date.isoformat(),
        "last_date": last_date.isoformat(),
        "period_days": period_days,
        "amounts": amounts,
    }