import pandas as pd
from logger import setup_logger

from app.common.utils import parse_date_params
from app.domains.overspending.repository import load_rules_from_file
from app.domains.transaction.repository import load_transactions_from_parquet

logger = setup_logger(__name__)

# --------------------------------
# public functions
# --------------------------------
def analyze_overspending(
    year: int | None = None,
    month: int | None = None,
    start_date: str | None = None,
    end_date: str | None = None
) -> list[dict]:
    """과소비 패턴 분석"""
    
    try:
        # 데이터 준비
        df = _prepare_expense_data(year, month, start_date, end_date)
        if df.empty:
            return []
        
        # 시간, 주, 월 데이터 추가
        df = _enrich_with_analysis_data(df)
        
        # 과소비 패턴 분석
        results = _analyze_overspending_patterns(df)
        
        logger.info(f"과소비 패턴 {len(results)}건 감지")
        return results
        
    except Exception as e:
        logger.error(f"과소비 분석 실패: {e}")
        raise


# --------------------------------
# private functions
# --------------------------------
def _prepare_expense_data(
    year: int | None = None,
    month: int | None = None,
    start_date: str | None = None,
    end_date: str | None = None
) -> pd.DataFrame:
    """거래 데이터 로드 및 지출 데이터 필터링
    
    Args:
        year: 연도 (선택)
        month: 월 (선택)
        start_date: 시작일 (YYYY-MM-DD 형식, 선택)
        end_date: 종료일 (YYYY-MM-DD 형식, 선택)
    
    Returns:
        필터링된 지출 데이터 DataFrame
    """
    # 날짜 파라미터 파싱
    start_date, end_date = parse_date_params(year, month, start_date, end_date)
    
    # 데이터 로드
    df = load_transactions_from_parquet()
    
    # 날짜 필터링
    df = _filter_by_date_range(df, start_date, end_date)
    if df.empty:
        return df
    
    # 지출 데이터만 필터링
    df = _filter_expense_only(df)
    
    return df


def _filter_by_date_range(
    df: pd.DataFrame,
    start_date: str | None,
    end_date: str | None
) -> pd.DataFrame:
    """날짜 범위로 데이터 필터링
    
    Args:
        df: 원본 DataFrame
        start_date: 시작일 (YYYY-MM-DD 형식)
        end_date: 종료일 (YYYY-MM-DD 형식)
    
    Returns:
        필터링된 DataFrame
    """
    if start_date:
        df = df[df["거래일시"] >= pd.to_datetime(start_date)]
    if end_date:
        df = df[df["거래일시"] <= pd.to_datetime(end_date)]
    
    return df


def _filter_expense_only(df: pd.DataFrame) -> pd.DataFrame:
    """지출 데이터만 필터링 및 금액 절댓값 변환
    
    Args:
        df: 원본 DataFrame
    
    Returns:
        지출 데이터만 포함한 DataFrame
    """
    df = df[df["타입"] == "지출"].copy()
    df["금액"] = df["금액"].abs()
    
    # 날짜 데이터 타입 확인
    if not pd.api.types.is_datetime64_any_dtype(df["거래일시"]):
        raise ValueError("거래일시 데이터 타입 오류 - 거래내역 parquet 파일을 확인해주세요.")
    
    return df


def _enrich_with_analysis_data(df: pd.DataFrame) -> pd.DataFrame:
    """시간, 주, 월 데이터 추가
    
    Args:
        df: 원본 DataFrame
    
    Returns:
        시간/주/월 데이터가 추가된 DataFrame
    """
    df["hour"] = df["거래일시"].dt.hour
    df["week"] = df["거래일시"].dt.isocalendar().week
    df["month"] = df["거래일시"].dt.to_period("M")
    
    return df


def _analyze_overspending_patterns(df: pd.DataFrame) -> list[dict]:
    """과소비 패턴 분석
    
    Args:
        df: 분석할 DataFrame
    
    Returns:
        과소비 패턴 리스트
    """
    rules = load_rules_from_file(include_disabled=False)
    results = [
        pattern for rule in rules
        if (pattern := _check_overspending(df, rule)) is not None
    ]
    
    return results


def _make_reason(type_: str, count: int, message: str) -> dict:
    """reason 딕셔너리 생성"""
    return {"type": type_, "count": count, "message": message}


def _filter_by_rule(df: pd.DataFrame, rule: dict) -> pd.DataFrame:
    """규칙에 따라 데이터 필터링"""
    # 카테고리 필터링
    filtered_df = df[df["대분류"] == rule["category_filter"]]
    if filtered_df.empty:
        return filtered_df
    
    # 시간대 필터 (선택)
    if "time_filter" in rule:
        start_hour, end_hour = rule["time_filter"]
        if start_hour > end_hour:
            time_mask = (filtered_df["hour"] >= start_hour) | (filtered_df["hour"] < end_hour)
        else:
            time_mask = (filtered_df["hour"] >= start_hour) & (filtered_df["hour"] < end_hour)
        filtered_df = filtered_df[time_mask]
    
    return filtered_df


def _check_overspending(df: pd.DataFrame, rule: dict) -> dict | None:
    """범용 과소비 체크 함수"""
    # 데이터 필터링
    filtered_df = _filter_by_rule(df, rule)
    if filtered_df.empty:
        return None

    total_amount = int(filtered_df["금액"].sum())
    reasons = []
    
    # 조건 체크 함수들을 딕셔너리로 관리
    checkers = {
        'weekly_count': _check_weekly_count,
        'monthly_count': _check_monthly_count,
        'monthly_total': _check_monthly_total,
        'per_transaction': _check_per_transaction,
    }
    
    # 각 조건 체크
    for key, checker in checkers.items():
        if key in rule:
            reason = checker(filtered_df, rule[key], rule.get('name', ''))
            if reason:
                reasons.append(reason)

    if not reasons:
        return None
    
    return {
        "category": rule["name"],
        "total_amount": total_amount,
        "reasons": reasons
    }


def _check_weekly_count(df: pd.DataFrame, threshold: int, rule_name: str) -> dict | None:
    """주별 빈도 체크"""
    weekly_counts = df.groupby("week").size()
    high_freq = weekly_counts[weekly_counts >= threshold]
    if len(high_freq) > 0:
        return _make_reason(
            "high_frequency",
            int(weekly_counts.sum()),
            f"주 {threshold}회 이상 ({len(high_freq)}주)"
        )
    return None


def _check_monthly_count(df: pd.DataFrame, threshold: int, rule_name: str) -> dict | None:
    """월별 빈도 체크"""
    monthly_counts = df.groupby("month").size()
    high_freq = monthly_counts[monthly_counts >= threshold]
    if len(high_freq) > 0:
        return _make_reason(
            "high_frequency",
            int(monthly_counts.sum()),
            f"월 {threshold}회 이상 ({len(high_freq)}개월)"
        )
    return None


def _check_monthly_total(df: pd.DataFrame, threshold: int, rule_name: str) -> dict | None:
    """월별 총액 체크"""
    monthly_total = df.groupby("month")["금액"].sum()
    high_months = monthly_total[monthly_total >= threshold]
    if len(high_months) > 0:
        return _make_reason(
            "high_monthly",
            len(df),
            f"월 총액 {threshold:,}원 초과 ({len(high_months)}개월)"
        )
    return None


def _check_per_transaction(df: pd.DataFrame, threshold: int, rule_name: str) -> dict | None:
    """건당 고액 체크"""
    expensive = df[df["금액"] >= threshold]
    if len(expensive) > 0:
        return _make_reason(
            "high_amount",
            len(expensive),
            f"건당 {threshold:,}원 이상 ({len(expensive)}건)"
        )
    return None