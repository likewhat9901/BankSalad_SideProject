from fastapi import Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from logger import setup_logger

logger = setup_logger(__name__)


def setup_exception_handlers(app):
    """FastAPI 앱에 예외 핸들러 등록"""
    
    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError):
        """ValueError를 400 Bad Request로 변환"""
        logger.warning(f"잘못된 요청: {exc}")
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": str(exc)},
        )
    
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        """예상치 못한 예외를 500 Internal Server Error로 변환"""
        logger.error(f"예상치 못한 오류 발생: {exc}", exc_info=True)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "내부 서버 오류가 발생했습니다."},
        )